# 🗺️ Mapa de Arquitetura — Perucaria Dr. Fire Esq.

## Fluxo de Navegação Entre Páginas

```
┌─────────────────────────────────────────────────────────────────┐
│                      TODAS AS PÁGINAS                          │
│  Header com: Logo | Menu | 🛒 Botão Carrinho (Badge)          │
└─────────────────────────────────────────────────────────────────┘
                            │
        ┌───────────────────┼───────────────────┐
        │                   │                   │
        ▼                   ▼                   ▼
    ┌─────────┐         ┌─────────┐        ┌──────────┐
    │ INDEX   │◄───────►│ PRODUTOS│       │ CARRINHO │
    │ .html   │◄────┐   │ .html   │◄─────►│ .html    │
    └─────────┘     │   └─────────┘       └──────────┘
         ▲          │        ▲                  ▲
         │          └────────┤──────────────────┘
         │                   │
         └───────────────────┴─ LOGIN.html
                             (Admin)
```

## Header — Componente Compartilhado

```
┌──────────────────────────────────────────────────────────┐
│                    SITE-HEADER                           │
├──────────────────────────────────────────────────────────┤
│  Logo + Título    │  Menu Nav  │  🛒 Carrinho (Badge)   │
│  Dr. Fire Esq.    │ - Início   │  [5] ← Quantidade      │
│  Perucaria        │ - Coleção  │  (Clickable → carrinho)│
│                   │ - Contato  │                        │
├──────────────────────────────────────────────────────────┤
│  Sticky Position | Z-index: 40 | Background com blur    │
└──────────────────────────────────────────────────────────┘
```

---

## Página: INDEX.html

```
┌─────────────────────────────────────────┐
│         HERO SECTION                    │
│  "Toda boa causa merece uma peruca"    │
│  [VER COLEÇÃO] ────────────┐            │
└─────────────────────────────────────────┘
                              │
         ┌────────────────────┘
         │ onclick: href="produtos.html"
         │
         ▼
    [PRODUTOS.HTML]

┌─────────────────────────────────────────┐
│     SOBRE O DOUTOR (section)            │
│  Histórico com imagem + blockquote       │
└─────────────────────────────────────────┘

┌─────────────────────────────────────────┐
│     DEPOIMENTOS (testimonials)           │
│  3 depoimentos cômica do povo            │
└─────────────────────────────────────────┘

┌─────────────────────────────────────────┐
│         FOOTER                          │
│  Contato | Endereço | Copyright         │
└─────────────────────────────────────────┘
```

---

## Página: PRODUTOS.html (Nova Integração)

```
┌─────────────────────────────────────────┐
│     HEADER (com botão 🛒)               │
│     TÍTULO: "Catálogo de Perucas"      │
│     [BUSCA]                             │
└─────────────────────────────────────────┘

┌──────────────────┐    ┌───────────────────────────────────┐
│   FILTROS        │    │   GRID DE PRODUTOS (3 visíveis)   │
│  (Sidebar Left)  │    │                                   │
│                  │    │  ┌──────────┐ ┌──────────┐        │
│ ☑ Todas          │    │  │ PRODUTO  │ │ PRODUTO  │        │
│ ☐ Femininas      │    │  │ 1        │ │ 2        │        │
│ ☐ Masculinas     │    │  │ R$ 299   │ │ R$ 189   │        │
│                  │    │  │ [ADICIONAR AO CARRINHO] ┐       │
│                  │    │  │          │ │          │ │       │
│                  │    │  └──────────┘ └──────────┘ │       │
│                  │    │                             │       │
│                  │    │  ┌──────────┐              │       │
│                  │    │  │ PRODUTO  │              │       │
│                  │    │  │ 3        │              │       │
│                  │    │  │ R$ 349   │              │       │
│                  │    │  │ [ADICIONAR AO CARRINHO]◄┘       │
│                  │    │  └──────────┘              │       │
│                  │    └───────────────────────────────────┘
│                  │
│  onclick: ├─────►  (Re)renderiza grid
│  data-filter      Filtra por categoria
│                   Busca por nome
└──────────────────┘

         🛒 [Botão Carrinho no Header]
          │
          └─ Clique: href="carrinho.html"
```

---

## Página: CARRINHO.html (✨ NOVA)

```
┌─────────────────────────────────────────────────────────┐
│  HEADER (com botão 🛒 — leva para si mesmo)            │
│  TÍTULO: "Carrinho de Compras"                         │
└─────────────────────────────────────────────────────────┘

┌──────────────────────────────┐  ┌──────────────────┐
│   LISTA DE ITENS             │  │  RESUMO (Sticky) │
│   (Main Column)              │  │  (Right Sidebar) │
│                              │  │                  │
│  ┌────────────────────────┐  │  │ Subtotal: R$... │
│  │ [IMG] PRODUTO 1        │  │  │ Frete: R$...    │
│  │ R$ 299,90 × 2          │  │  │ ├──────────────  │
│  │ [−] [2] [+]  Subtot... │  │  │ TOTAL: R$...    │
│  │          [✕ Remover]   │  │  │                  │
│  └────────────────────────┘  │  │ [CHECKOUT BTN]   │
│                              │  │ [Continuar...]   │
│  ┌────────────────────────┐  │  └──────────────────┘
│  │ [IMG] PRODUTO 2        │  │
│  │ R$ 189,50 × 1          │  │
│  │ [−] [1] [+]  Subtot... │  │
│  │          [✕ Remover]   │  │
│  └────────────────────────┘  │
│                              │
│  (Se carrinho vazio:)        │
│  ┌────────────────────────┐  │
│  │ "Carrinho Vazio"       │  │
│  │ [VER PERUCAS] ─────────┼──┼─► produtos.html
│  └────────────────────────┘  │
└──────────────────────────────┘

Funcionalidades:
• [−] [+] atualiza quantidade via window.carrinho
• [✕] remove item (com confirmação)
• Cálculo de frete automático
• CHECKOUT mostra alerta com total
• localStorage persiste carrinho
```

---

## Sistema de Carrinho — Arquitetura JavaScript

```
┌─────────────────────────────────────────────────────┐
│           window.carrinho (Classe)                  │
│                                                      │
│  Properties:                                         │
│  ├─ items[]  (array de objetos com id, nome,...)   │
│  ├─ localStorage: 'carrinho_dr_fire'               │
│  └─ listeners auto-update do badge                 │
│                                                      │
│  Methods:                                            │
│  ├─ addItem(id, nome, preco, imagem)              │
│  ├─ removeItem(id)                                 │
│  ├─ updateQuantidade(id, qty)                      │
│  ├─ getTotal() → number                            │
│  ├─ getQuantidadeTotal() → number                  │
│  ├─ getItems() → array                             │
│  ├─ limpar()                                        │
│  └─ loadFromStorage() / saveToStorage()            │
│                                                      │
└─────────────────────────────────────────────────────┘
         │                          │
         │                          │
         ▼                          ▼
   js/carrinho.js           js/cart-page.js
   (Backend Logic)          (UI Rendering)
   
   • Gerencia estado       • Renderiza itens
   • localStorage          • Eventos de botões
   • Cálculos             • Form de quantidade
   • Badge update         • Resumo de compra

         ▲                          ▲
         │                          │
    Chamado de:              Chamado de:
    • produtos.html          • carrinho.html
    • Qualquer página        • Menu mobile
    (adicionarAoCarrinho)
```

---

## CSS — Organização

```
style.css (550+ linhas)
│
├─ :root (Variáveis de cores)
├─ Reset & Base
├─ Header Styles
│  └─ .cart-button (botão 🛒)
│  └─ .cart-badge (contador)
│
├─ Navigation
├─ Buttons & Links
├─ Hero Section
├─ Forms
├─ Tables
├─ Cards
│
├─ PAGE-SPECIFIC (Nova Seção)
│  ├─ .page-carrinho
│  ├─ .cart-container
│  ├─ .cart-item
│  ├─ .cart-summary
│  ├─ .qty-btn
│  └─ .btn-checkout
│
└─ Media Queries (Responsividade)
   ├─ @media (max-width: 820px)
   └─ @media (max-width: 680px)
```

---

## localStorage — Estrutura de Dados

```javascript
// Chave: 'carrinho_dr_fire'
// Valor (JSON):

[
  {
    "id": "prod-001",
    "nome": "Peruca Feminina Longa Ondulada Castanha",
    "preco": 299.90,
    "imagem": "https://via.placeholder.com/...",
    "quantidade": 2
  },
  {
    "id": "prod-002",
    "nome": "Prótese Capilar Masculina Curta",
    "preco": 189.50,
    "imagem": "https://via.placeholder.com/...",
    "quantidade": 1
  }
]

// Cálculos Automáticos:
Subtotal = (299.90 × 2) + (189.50 × 1) = R$ 788.30
Frete    = 788.30 × 0.05 = R$ 39.42 (MIN R$ 15)
TOTAL    = 788.30 + 39.42 = R$ 827.72
```

---

## Fluxo de Dados — Adicionar ao Carrinho

```
USER ACTION (produtos.html)
    │
    └─ Clica [ADICIONAR AO CARRINHO]
       └─ onclick="adicionarAoCarrinho('prod-001', 'Nome', 299.90, 'img')"
    │
    ▼
FUNCTION GLOBAL (js/carrinho.js)
    │
    └─ adicionarAoCarrinho()
       └─ window.carrinho.addItem(...)
    │
    ▼
CLASS METHOD (Carrinho.addItem)
    │
    ├─ Checa se produto já existe
    ├─ Se sim: incrementa quantidade
    ├─ Se não: cria novo objeto
    └─ Chama saveToStorage()
    │
    ▼
STORAGE UPDATE
    │
    └─ localStorage.setItem('carrinho_dr_fire', JSON)
    │
    ▼
VISUAL UPDATE
    │
    └─ updateBadge()
       └─ document.getElementById('cartBadge').textContent = qty
    │
    ▼
ANIMATION (CSS)
    │
    └─ @keyframes pulse → badge pisca
```

---

## Responsividade — Breakpoints

```
DESKTOP (>1024px)
├─ Grid 2 colunas (carrinho + resumo)
├─ Menu horizontal
├─ Imagens 100px × 100px
└─ Resumo sticky (position: sticky)

TABLET (768px - 1024px)
├─ Grid 1 coluna
├─ Menu hamburguês
├─ Resumo adaptado
└─ Imagens 80px × 80px

MOBILE (<768px)
├─ Stack vertical completo
├─ Menu hamburguês (visible: block)
├─ Botões touch-friendly
└─ Badge no topo do header
```

---

## 📊 Resumo Visual

```
ANTES                          DEPOIS (Atual)
─────────────────────────────  ──────────────────────
index.html              index.html  ✨+ [🛒 Badge]
produtos.html           produtos.html ✨+ [🛒 Badge]
login.html              └─► carrinho.html ✨ NOVO
                        login.html
css/
├─ style.css            css/
└─ styleLogin.css       ├─ style.css (+ seções carrinho)
                        └─ styleLogin.css
scripts/
├─ script.js            js/ ✨ NOVO
└─ produtos.js          ├─ carrinho.js ✨ NOVO
                        └─ cart-page.js ✨ NOVO
                        
                        scripts/
                        ├─ script.js
                        └─ produtos.js
```

---

**Diagrama atualizado: 23/09/2026**  
*Projeto em desenvolvimento ativo com arquitetura escalável* 🚀
